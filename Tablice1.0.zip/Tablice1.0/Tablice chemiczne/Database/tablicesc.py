import tkinter as tk
from tkinter import ttk
import sys
sys.path.append("C:\\Program Files\\Tablice chemiczne")
sys.path.append("C")
sys.path.append("C:\\Program Files\\Tablice chemiczne\\Database\\Tablice")

from uklad_okresowy_i import uklad


def lista_tablic():
    x=0
    import tkinter as tk
    print("[Otwarto listę tablic]")
    lista = tk.Toplevel()
    lista.title("Lista tablic")
    lista.geometry("550x700")
    lista.iconbitmap("C:\\Program Files\\Tablice chemiczne\\icon.ico")
    info0 = tk.Label(lista, text="Wybrane tablice chemiczne", font=("Arial", 14))
    info1 = tk.Label(lista, text="Ustawione w kolejności alfabetycznej", font=("Arial", 14))
    info0.pack(pady=2, padx=20)
    info1.pack(pady=2, padx=20)
    tb = tk.Frame(lista, bg="lightgray", bd=5, relief="ridge")
    tb.pack(pady=2, padx=20)
    okresowyb = tk.Button(tb, text="Układ okresowy-interaktywny", command=uklad)

    def rozpuszczalnosct():
        try:
            trozp = tk.Toplevel()
            trozp.title("Tablica rozpuszczalności")
            trozp.geometry('1071x700')
            trozp.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img0 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\Tablica rozpuszczalnosci.png')
            tk.Label(trozp, image=img0).pack()
            trozp.image = img0
            print("[Otwarto Tablicę rozpuszczalności]")
        except:
            print("error: rozpuszczalnosct, trozp, tablicesc.py")
    trozpb = tk.Button(tb, text="Rozpuszczalność tablica", command=rozpuszczalnosct)
    def okresowy():
        try:
            ok = tk.Toplevel()
            ok.title("Tablica rozpuszczalności")
            ok.geometry('1105x700')
            ok.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img1 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\uklad okresowy.png')
            tk.Label(ok, image=img1).pack()
            ok.image = img1
            print("[Otwarto Układ okresowy]")
        except:
            print("error: okresowy, ok, tablicesc.py")
    okb = tk.Button(tb, text="Układ okresowy", command=okresowy)
    def potencjałh2o():
        try:
            pW = tk.Toplevel()
            pW.title("Potencjał wody w komórce roślinnej")
            pW.geometry('745x200')
            pW.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img2 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\potencjal wody.png')
            tk.Label(pW, image=img2).pack()
            pW.image = img2
            print("[Otwarto Potencjał wody w komórce roślinnej]")
        except:
            print("error: potencjałh2o, pW, tablicesc.py")
    pWb = tk.Button(tb, text="Potencjał wody w k. roślinnej", command=potencjałh2o)
    def rownanieHW():
        try:
            rHW = tk.Toplevel()
            rHW.title("Równanie Hardy'ego-Weibnerga")
            rHW.geometry('745x200')
            rHW.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img3 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\Rownanie Hardyego-Weibnerga.png')
            tk.Label(rHW, image=img3).pack()
            rHW.image = img3
            print("[Otwarto Równanie Hardy'ego-Weibnerga]")
        except:
            print("error: rownanieHw, rHW, tablicesc.py")
    rHWb = tk.Button(tb, text="Równanie Hardy'ego-Weibnerga", command=rownanieHW)
    def kworg():
        try:
            kor = tk.Toplevel()
            kor.title("Wybrane kwasy organiczne")
            kor.geometry('686x300')
            kor.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img4 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\Wybrane kwasy organiczne.png')
            tk.Label(kor, image=img4).pack()
            kor.image = img4
            print("[Otwarto Wybrane kwasy organiczne]")
        except:
            print("error: kworg, kor, tablicesc.py")
    korb = tk.Button(tb, text="Wybrane kwasy organiczne", command=kworg)
    def hATP():
        try:
            hatp = tk.Toplevel()
            hatp.title("hydroliza ATP")
            hatp.geometry('732x600')
            hatp.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img5 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\hydroliza ATP.png')
            tk.Label(hatp, image=img5).pack()
            hatp.image = img5
            print("[Otwarto hydroliza ATP]")
        except:
            print("error: hATP, hatp, tablicesc.py")
    hatpb = tk.Button(tb, text="hydroliza ATP", command=hATP)
    def kodgen():
        try:
            kodg = tk.Toplevel()
            kodg.title("kod genetyczny")
            kodg.geometry('846x600')
            kodg.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img6 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\kod genetyczny.png')
            tk.Label(kodg, image=img6).pack()
            kodg.image = img6
            print("[Otwarto kod genetyczny]")
        except:
            print("error: kodgen, kodg, tablicesc.py")
    kodgb = tk.Button(tb, text="kod genetyczny", command=kodgen)
    def Log10():
        try:
            l10 = tk.Toplevel()
            l10.title("logarytmy dziesiętne")
            l10.geometry('456x700')
            l10.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img7 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\logarytmy dziesietne.png')
            tk.Label(l10, image=img7).pack()
            l10.image = img7
            print("[Otwarto logarytmy dziesiętne]")
        except:
            print("error: Log10, l10, tablicesc.py")
    l10b = tk.Button(tb, text="logarytmy dziesiętne", command=Log10)
    def irws():
        try:
            irs = tk.Toplevel()
            irs.title("iloczyn rozpuszczalności wybranych substancji")
            irs.geometry('510x700')
            irs.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img8 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\iloczyn rozpuszczalnosci wybranych substancji.png')
            tk.Label(irs, image=img8).pack()
            irs.image = img8
            print("[Otwarto iloczyn rozpuszczalności wybranych substancji]")
        except:
            print("error: irws, irs, tablicesc.py")
    irsb = tk.Button(tb, text="iloczyn rozpuszczalności wybranych substancji", command=irws)
    def pwzs():
        try:
            pws = tk.Toplevel()
            pws.title("podstawowe wzory ze statystyki")
            pws.geometry('439x700')
            pws.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img9 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\podstawowe wzory ze statystyki.png')
            tk.Label(pws, image=img9).pack()
            pws.image = img9
            print("[Otwarto podstawowe wzory ze statystyki]")
        except:
            print("error: pwzs, pws, tablicesc.py")
    pwsb = tk.Button(tb, text="podstawowe wzory ze statystyki", command=pwzs)
    def psrf():
        try:
            psr = tk.Toplevel()
            psr.title("potencjał standardowy redukcji")
            psr.geometry('1098x700')
            psr.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img10 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\potencjal standardowy redukcji.png')
            tk.Label(psr, image=img10).pack()
            psr.image = img10
            print("[Otwarto potencjał standardowy redukcji]")
        except:
            print("error: psrf, psr, tablicesc.py")
    psrb = tk.Button(tb, text="potencjał standardowy redukcji", command=psrf)
    def sdwgf():
        try:
            sdwg = tk.Toplevel()
            sdwg.title("średnie długości wiązań w gazach")
            sdwg.geometry('589x400')
            sdwg.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img11 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\srednie dlugosci wiazan w czasteczkach w fazie gazowej.png')
            tk.Label(sdwg, image=img11).pack()
            sdwg.image = img11
            print("[Otwarto średnie długości wiązań w gazach]")
        except:
            print("error: sdwgf, sdwg, tablicesc.py")
    sdwgb = tk.Button(tb, text="średnie długości wiązań w gazach", command=sdwgf)
    def sdgfaf():
        try:
            sdgfa = tk.Toplevel()
            sdgfa.title("stałe dysocjacji grup funkcyjnych aminokwasów")
            sdgfa.geometry('1055x700')
            sdgfa.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img12 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\stale dysocjacji dla grup funkcyjnych aminokwasow.png')
            tk.Label(sdgfa, image=img12).pack()
            sdgfa.image = img12
            print("[Otwarto stałe dysocjacji grup funkcyjnych aminokwasów]")
        except:
            print("error: sdgfaf, sdgfa, tablicesc.py")
    sdgfab = tk.Button(tb, text="stałe dysocjacji grup funkcyjnych aminokwasów", command=sdgfaf)
    def zaf():
        try:
            za = tk.Toplevel()
            za.title("zasady azotowe")
            za.geometry('600x412')
            za.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img13 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\zasady azotowe.png')
            tk.Label(za, image=img13).pack()
            za.image = img13
            print("[Otwarto zasady azotowe]")
        except:
            print("error: zaf, za, tablicesc.py")
    zab = tk.Button(tb, text="zasady azotowe", command=zaf)
    def wkzf():
        try:
            wkz = tk.Toplevel()
            wkz.title("wskaźniki kwasowo-zasadowe")
            wkz.geometry('1072x700')
            wkz.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img14 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\wybrane wskazniki kwasowo zasadowe.png')
            tk.Label(wkz, image=img14).pack()
            wkz.image = img14
            print("[Otwarto wskaźniki kwasowo-zasadowe]")
        except:
            print("error: wkzf, wkz, tablicesc.py")
    wkzb = tk.Button(tb, text="wskaźniki kwasowo-zasadowe", command=wkzf)
    def wkpf():
        try:
            wkp = tk.Toplevel()
            wkp.title("wpływ kierujacy podstawników w pierscieniu aromatycznym")
            wkp.geometry('605x250')
            wkp.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img15 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\wpływ kierujacy podstawnikow w pierscieniu aromatycznym.png')
            tk.Label(wkp, image=img15).pack()
            wkp.image = img15
            print("[Otwarto wpływ kierujacy podstawników w pierscieniu aromatycznym]")
        except:
            print("error: wkpf, wkp, tablicesc.py")
    wkpb = tk.Button(tb, text="wpływ kierujacy podstawników w pierscieniu aromatycznym", command=wkpf)
    def sdkzf():
        try:
            sdkz = tk.Toplevel()
            sdkz.title("stałe dysocjacji wybranych kwasów i zasad")
            sdkz.geometry('1021x700')
            sdkz.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img16 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\stale dysocjacji wybranych kwasow i zasad.png')
            tk.Label(sdkz, image=img16).pack()
            sdkz.image = img16
            print("[Otwarto stałe dysocjacji wybranych kwasów i zasad]")
        except:
            print("error: sdkzf, sdkz, tablicesc.py")
    sdkzb = tk.Button(tb, text="stałe dysocjacji wybranych kwasów i zasad", command=sdkzf)
    def smetf():
        try:
            smet = tk.Toplevel()
            smet.title("standardowa molowa entlapia tworzenia")
            smet.geometry('524x600')
            smet.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img17 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\standardowa molowa entlapia tworzenia.png')
            tk.Label(smet, image=img17).pack()
            smet.image = img17
            print("[Otwarto standardowa molowa entlapia tworzenia]")
        except:
            print("error: smetf, smet, tablicesc.py")
    smetb = tk.Button(tb, text="standardowa molowa entlapia tworzenia", command=smetf)
    def smesf():
        try:
            smes = tk.Toplevel()
            smes.title("standardowa molowa entlapia spalania")
            smes.geometry('560x500')
            smes.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
            img18 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\standardowa molowa entlapia spalania.png')
            tk.Label(smes, image=img18).pack()
            smes.image = img18
            print("[Otwarto standardowa molowa entlapia spalania]")
        except:
            print("error: smesf, smes, tablicesc.py")
    smesb = tk.Button(tb, text="standardowa molowa entlapia spalania", command=smesf)
    from abf2 import abf
    abfb = tk.Button(tb, text="aminokwasy białkowe", command=abf)

    
    abfb.grid(row=0, column=0, padx=0)
    hatpb.grid(row=1, column=0, padx=0)
    irsb.grid(row=2, column=0, padx=0)
    kodgb.grid(row=3, column=0, padx=0)
    korb.grid(row=19, column=0, padx=0)
    l10b.grid(row=4, column=0, padx=0)
    okb.grid(row=5, column=0, padx=0)
    okresowyb.grid(row=6, column=0, padx=0)
    psrb.grid(row=7, column=0, padx=0)
    pWb.grid(row=8, column=0, padx=0)
    pwsb.grid(row=9, column=0, padx=0)
    rHWb.grid(row=11, column=0, padx=0)
    sdgfab.grid(row=12, column=0, padx=0)
    sdkzb.grid(row=13, column=0, padx=0)
    sdwgb.grid(row=14, column=0, padx=0)
    smesb.grid(row=15, column=0, padx=0)
    smetb.grid(row=16, column=0, padx=0)
    trozpb.grid(row=10, column=0, padx=0)
    wkpb.grid(row=17, column=0, padx=0)
    wkzb.grid(row=18, column=0, padx=0)
    zab.grid(row=20, column=0, padx=0)
    

    lista.mainloop()
    
    

