import sys
sys.path.append("C:\\Program Files\\Tablice chemiczne\\Database")
sys.path.append("C:\\Program Files\\Tablice chemiczne\\Database\\pierwiastki")

import tkinter as tk

from H import Wodor
from He import Hel
from Li import Lit

from B import Bor
from C import Wegiel
from N import Azot
from O import Tlen
from F import Fluor
from Ne import Neon

from Na import Sód
from Mg import Magnez
from Al import Glin
from Si import Krzem
from P import Fosfor
from S import Siarka
from Cl import Chlor
from Ar import Argon

from K_Ca_Sc import *
from Ti_V_Cr_Fe_Co import *
from Mn_Ni_Cu import *
from Zn import Cynk
from Ga import Gal
from Ge import German
from As import Astat
from Se import Selen
from Br import Brom
from Kr import Krypton

from Rb import Rubid
from Sr import Stront
from Y import Itr
from Zr import Cyrkon
from Nb import Niob
from Mo import Molibden
from Tc import Technet
from Ru import Rutenu
from Rh import Rodu
from Pd import Pallad
from Ag import Srebro
from Cd import Kadm
from In import Ind
from Sn import Cyna
from Sb import Antymon
from Te import Tellur
from I import Jod
from Xe import Ksenon

from Cs import Cez
from Ba import Bar
from La import Lantan
from Hf import Hafn
from Ta import Tantal
from W import Wolfram
from Re import Ren
from Os import Osm
from Ir import Iryd
from Pt import Platyna
from Au import Zloto
from Hg import Rtec
from Tl import Tal
from Pb import Olow
from Bi import Bizmut
from Po import Polon
from At import Astat
from Rn import Radon

from Fr import Frans
from Ra import Rad
from Ac import Aktyn
from Rf import Rutherford
from Db import Dubn
from Sg import Seaborg
from Bh import Bohr
from Hs import Has
from Mt import Meitner
from Ds import Darmsztadt
from Rg import Roentgen
from Cn import Kopernik
from Nh import Nihon
from Fl import Flerow
from Mc import Moskow
from Lv import Liwermor
from Ts import Tenes
from Og import Oganeson

from Ce import Cer
from Dy import Dysproz
from Er import Erb
from Eu import Europ
from Gd import Gadolin
from Ho import Holm
from Lu import Lutet
from Nd import Neodym
from Np import Neptun
from Pa import Protaktyn
from Pm import Promet
from Pr import Prazeodym
from Sm import Samar
from Tb import Terb
from Th import Tor
from Tm import Tal
from U import Uran
from Yb import Iterb
from Pu import Pluton
from Am import Ameryk
from Cm import Kiur
from Bk import Berkel
from Cf import Kaliforn
from Es import Einstein
from Fm import Ferm
from Md import Mendelew
from No import Nobel
from Lr import Lorens

def uklad():
    print("[Otwarto interaktywny układ okresowy]")
    root2 = tk.Tk()
    root2.title("Układ okresowy")
    root2.geometry("750x400")
    sys.path.append("C:\\Program Files\\Tablice chemiczne")
    root2.iconbitmap("C:\\Program Files\\Tablice chemiczne\\icon.ico")
    uklad = tk.Frame(root2, bg="lightgray", bd=5, relief="ridge")
    uklad.pack(pady=2, padx=20)
    buttonH = tk.Button(uklad, text="H", command=Wodor)
    buttonHe = tk.Button(uklad, text="He", command=Hel)
    buttonH.grid(row=0, column=0, padx=5, pady=5)
    buttonHe.grid(row=0, column=17, padx=5, pady=5)
    buttonLi = tk.Button(uklad, text="Li", command=Lit)
    buttonBe = tk.Button(uklad, text="Be")
    buttonB = tk.Button(uklad, text="B", command=Bor)
    buttonC = tk.Button(uklad, text="C", command=Wegiel)
    buttonN = tk.Button(uklad, text="N", command=Azot)
    buttonO = tk.Button(uklad, text="O", command=Tlen)
    buttonF = tk.Button(uklad, text="F", command=Fluor)
    buttonNe = tk.Button(uklad, text="Ne", command=Neon)
    buttonLi.grid(row=1, column=0, padx=5, pady=5)
    buttonBe.grid(row=1, column=1, padx=5, pady=5)
    buttonB.grid(row=1, column=12, padx=5, pady=5)
    buttonC.grid(row=1, column=13, padx=5, pady=5)
    buttonN.grid(row=1, column=14, padx=5, pady=5)
    buttonO.grid(row=1, column=15, padx=5, pady=5)
    buttonF.grid(row=1, column=16, padx=5, pady=5)
    buttonNe.grid(row=1, column=17, padx=5, pady=5)
    buttonNa = tk.Button(uklad, text="Na", command=Sód)
    buttonMg = tk.Button(uklad, text="Mg", command=Magnez)
    buttonAl = tk.Button(uklad, text="Al", command=Glin)
    buttonSi = tk.Button(uklad, text="Si", command=Krzem)
    buttonP = tk.Button(uklad, text="P", command=Fosfor)
    buttonS = tk.Button(uklad, text="S", command=Siarka)
    buttonCl = tk.Button(uklad, text="Cl", command=Chlor)
    buttonAr = tk.Button(uklad, text="Ar", command=Argon)
    buttonNa.grid(row=2, column=0, padx=5, pady=5)
    buttonMg.grid(row=2, column=1, padx=5, pady=5)
    buttonAl.grid(row=2, column=12, padx=5, pady=5)
    buttonSi.grid(row=2, column=13, padx=5, pady=5)
    buttonP.grid(row=2, column=14, padx=5, pady=5)
    buttonS.grid(row=2, column=15, padx=5, pady=5)
    buttonCl.grid(row=2, column=16, padx=5, pady=5)
    buttonAr.grid(row=2, column=17, padx=5, pady=5)
    buttonK = tk.Button(uklad, text="K", command=Potas)
    buttonCa = tk.Button(uklad, text="Ca", command=Wapń)
    buttonSc = tk.Button(uklad, text="Sc", command=Skand)
    buttonTi = tk.Button(uklad, text="Ti", command=Tytan)
    buttonV = tk.Button(uklad, text="V", command=Wanad)
    buttonCr = tk.Button(uklad, text="Cr", command=Chrom)
    buttonMn = tk.Button(uklad, text="Mn", command=Mangan)
    buttonFe = tk.Button(uklad, text="Fe", command=Żelazo)
    buttonCo = tk.Button(uklad, text="Co", command=Kobalt)
    buttonNi = tk.Button(uklad, text="Ni", command=Nikiel)
    buttonCu = tk.Button(uklad, text="Cu", command=Miedź)
    buttonZn = tk.Button(uklad, text="Zn", command=Cynk)
    buttonGa = tk.Button(uklad, text="Ga", command=Gal)
    buttonGe = tk.Button(uklad, text="Ge", command=German)
    buttonAs = tk.Button(uklad, text="As", command=Astat)
    buttonSe = tk.Button(uklad, text="Se", command=Selen)
    buttonBr = tk.Button(uklad, text="Br", command=Brom)
    buttonKr = tk.Button(uklad, text="Kr", command=Krypton)
    buttonK.grid(row=3, column=0, padx=5, pady=5)
    buttonCa.grid(row=3, column=1, padx=5, pady=5)
    buttonSc.grid(row=3, column=2, padx=5, pady=5)
    buttonTi.grid(row=3, column=3, padx=5, pady=5)
    buttonV.grid(row=3, column=4, padx=5, pady=5)
    buttonCr.grid(row=3, column=5, padx=5, pady=5)
    buttonMn.grid(row=3, column=6, padx=5, pady=5)
    buttonFe.grid(row=3, column=7, padx=5, pady=5)
    buttonCo.grid(row=3, column=8, padx=5, pady=5)
    buttonNi.grid(row=3, column=9, padx=5, pady=5)
    buttonCu.grid(row=3, column=10, padx=5, pady=5)
    buttonZn.grid(row=3, column=11, padx=5, pady=5)
    buttonGa.grid(row=3, column=12, padx=5, pady=5)
    buttonGe.grid(row=3, column=13, padx=5, pady=5)
    buttonAs.grid(row=3, column=14, padx=5, pady=5)
    buttonSe.grid(row=3, column=15, padx=5, pady=5)
    buttonBr.grid(row=3, column=16, padx=5, pady=5)
    buttonKr.grid(row=3, column=17, padx=5, pady=5)
    buttonRb = tk.Button(uklad, text="Rb", command=Rubid)
    buttonSr = tk.Button(uklad, text="Sr", command=Stront)
    buttonY = tk.Button(uklad, text="Y", command=Itr)
    buttonZr = tk.Button(uklad, text="Zr", command=Cyrkon)
    buttonNb = tk.Button(uklad, text="Nb", command=Niob)
    buttonMo = tk.Button(uklad, text="Mo", command=Molibden)
    buttonTc = tk.Button(uklad, text="Tc", command=Technet)
    buttonRu = tk.Button(uklad, text="Ru", command=Rutenu)
    buttonRh = tk.Button(uklad, text="Rh", command=Rodu)
    buttonPd = tk.Button(uklad, text="Pd", command=Pallad)
    buttonAg = tk.Button(uklad, text="Ag", command=Srebro)
    buttonCd = tk.Button(uklad, text="Cd", command=Kadm)
    buttonIn = tk.Button(uklad, text="In", command=Ind)
    buttonSn = tk.Button(uklad, text="Sn", command=Cyna)
    buttonSb = tk.Button(uklad, text="Sb", command=Antymon)
    buttonTe = tk.Button(uklad, text="Te", command=Tellur)
    buttonI = tk.Button(uklad, text="I", command=Jod)
    buttonXe = tk.Button(uklad, text="Xe", command=Ksenon)
    buttonRb.grid(row=4, column=0, padx=5, pady=5)
    buttonSr.grid(row=4, column=1, padx=5, pady=5)
    buttonY.grid(row=4, column=2, padx=5, pady=5)
    buttonZr.grid(row=4, column=3, padx=5, pady=5)
    buttonNb.grid(row=4, column=4, padx=5, pady=5)
    buttonMo.grid(row=4, column=5, padx=5, pady=5)
    buttonTc.grid(row=4, column=6, padx=5, pady=5)
    buttonRu.grid(row=4, column=7, padx=5, pady=5)
    buttonRh.grid(row=4, column=8, padx=5, pady=5)
    buttonPd.grid(row=4, column=9, padx=5, pady=5)
    buttonAg.grid(row=4, column=10, padx=5, pady=5)
    buttonCd.grid(row=4, column=11, padx=5, pady=5)
    buttonIn.grid(row=4, column=12, padx=5, pady=5)
    buttonSn.grid(row=4, column=13, padx=5, pady=5)
    buttonSb.grid(row=4, column=14, padx=5, pady=5)
    buttonTe.grid(row=4, column=15, padx=5, pady=5)
    buttonI.grid(row=4, column=16, padx=5, pady=5)
    buttonXe.grid(row=4, column=17, padx=5, pady=5)
    buttonCs = tk.Button(uklad, text="Cs", command=Cez)
    buttonBa = tk.Button(uklad, text="Ba", command=Bar)
    buttonLa = tk.Button(uklad, text="La", command=Lantan)
    buttonHf = tk.Button(uklad, text="Hf", command=Hafn)
    buttonTa = tk.Button(uklad, text="Ta", command=Tantal)
    buttonW = tk.Button(uklad, text="W", command=Wolfram)
    buttonRe = tk.Button(uklad, text="Re", command=Ren)
    buttonOs = tk.Button(uklad, text="Os", command=Osm)
    buttonIr = tk.Button(uklad, text="Ir", command=Iryd)
    buttonPt = tk.Button(uklad, text="Pt", command=Platyna)
    buttonAu = tk.Button(uklad, text="Au", command=Zloto)
    buttonHg = tk.Button(uklad, text="Hg", command=Rtec)
    buttonTl = tk.Button(uklad, text="Tl", command=Tal)
    buttonPb = tk.Button(uklad, text="Pb", command=Olow)
    buttonBi = tk.Button(uklad, text="Bi", command=Bizmut)
    buttonPo = tk.Button(uklad, text="Po", command=Polon)
    buttonAt = tk.Button(uklad, text="At", command=Astat)
    buttonRn = tk.Button(uklad, text="Rn", command=Radon)
    buttonCs.grid(row=5, column=0, padx=5, pady=5)
    buttonBa.grid(row=5, column=1, padx=5, pady=5)
    buttonLa.grid(row=5, column=2, padx=5, pady=5)
    buttonHf.grid(row=5, column=3, padx=5, pady=5)
    buttonTa.grid(row=5, column=4, padx=5, pady=5)
    buttonW.grid(row=5, column=5, padx=5, pady=5)
    buttonRe.grid(row=5, column=6, padx=5, pady=5)
    buttonOs.grid(row=5, column=7, padx=5, pady=5)
    buttonIr.grid(row=5, column=8, padx=5, pady=5)
    buttonPt.grid(row=5, column=9, padx=5, pady=5)
    buttonAu.grid(row=5, column=10, padx=5, pady=5)
    buttonHg.grid(row=5, column=11, padx=5, pady=5)
    buttonTl.grid(row=5, column=12, padx=5, pady=5)
    buttonPb.grid(row=5, column=13, padx=5, pady=5)
    buttonBi.grid(row=5, column=14, padx=5, pady=5)
    buttonPo.grid(row=5, column=15, padx=5, pady=5)
    buttonAt.grid(row=5, column=16, padx=5, pady=5)
    buttonRn.grid(row=5, column=17, padx=5, pady=5)
    buttonFr = tk.Button(uklad, text="Fr", command=Frans)
    buttonRa = tk.Button(uklad, text="Ra", command=Rad)
    buttonAc = tk.Button(uklad, text="Ac", command=Aktyn)
    buttonRf = tk.Button(uklad, text="Rf", command=Rutherford)
    buttonDb = tk.Button(uklad, text="Db", command=Dubn)
    buttonSg = tk.Button(uklad, text="Sg", command=Seaborg)
    buttonBh = tk.Button(uklad, text="Bh", command=Bohr)
    buttonHs = tk.Button(uklad, text="Hs", command=Has)
    buttonMt = tk.Button(uklad, text="Mt", command=Meitner)
    buttonDs = tk.Button(uklad, text="Ds", command=Darmsztadt)
    buttonRg = tk.Button(uklad, text="Rg", command=Roentgen)
    buttonCn = tk.Button(uklad, text="Cn", command=Kopernik)
    buttonNh = tk.Button(uklad, text="Nh", command=Nihon)
    buttonFl = tk.Button(uklad, text="Fl", command=Flerow)
    buttonMc = tk.Button(uklad, text="Mc", command=Moskow)
    buttonLv = tk.Button(uklad, text="Lv", command=Liwermor)
    buttonTs = tk.Button(uklad, text="Ts", command=Tenes)
    buttonOg = tk.Button(uklad, text="Og", command=Oganeson)
    buttonFr.grid(row=6, column=0, padx=5, pady=5)
    buttonRa.grid(row=6, column=1, padx=5, pady=5)
    buttonAc.grid(row=6, column=2, padx=5, pady=5)
    buttonRf.grid(row=6, column=3, padx=5, pady=5)
    buttonDb.grid(row=6, column=4, padx=5, pady=5)
    buttonSg.grid(row=6, column=5, padx=5, pady=5)
    buttonBh.grid(row=6, column=6, padx=5, pady=5)
    buttonHs.grid(row=6, column=7, padx=5, pady=5)
    buttonMt.grid(row=6, column=8, padx=5, pady=5)
    buttonDs.grid(row=6, column=9, padx=5, pady=5)
    buttonRg.grid(row=6, column=10, padx=5, pady=5)
    buttonCn.grid(row=6, column=11, padx=5, pady=5)
    buttonNh.grid(row=6, column=12, padx=5, pady=5)
    buttonFl.grid(row=6, column=13, padx=5, pady=5)
    buttonMc.grid(row=6, column=14, padx=5, pady=5)
    buttonLv.grid(row=6, column=15, padx=5, pady=5)
    buttonTs.grid(row=6, column=16, padx=5, pady=5)
    buttonOg.grid(row=6, column=17, padx=5, pady=5)
    uklad2 = tk.Frame(root2, bg="lightgray", bd=5, relief="ridge")
    uklad2.pack(pady=2, padx=100)
    buttonCe = tk.Button(uklad2, text="Ce", command=Cer)
    buttonPr = tk.Button(uklad2, text="Pr", command=Prazeodym)
    buttonNd = tk.Button(uklad2, text="Nd", command=Neodym)
    buttonPm = tk.Button(uklad2, text="Pm", command=Promet)
    buttonSm = tk.Button(uklad2, text="Sm", command=Samar)
    buttonEu = tk.Button(uklad2, text="Eu", command=Europ)
    buttonGd = tk.Button(uklad2, text="Gd", command=Gadolin)
    buttonTb = tk.Button(uklad2, text="Tb", command=Terb)
    buttonDy = tk.Button(uklad2, text="Dy", command=Dysproz)
    buttonHo = tk.Button(uklad2, text="Ho", command=Holm)
    buttonEr = tk.Button(uklad2, text="Er", command=Erb)
    buttonTm = tk.Button(uklad2, text="Tm", command=Tal)
    buttonYb = tk.Button(uklad2, text="Yb", command=Iterb)
    buttonLu = tk.Button(uklad2, text="Lu", command=Lutet)
    buttonCe.grid(row=0, column=4, padx=5, pady=5)
    buttonPr.grid(row=0, column=5, padx=5, pady=5)
    buttonNd.grid(row=0, column=6, padx=5, pady=5)
    buttonPm.grid(row=0, column=7, padx=5, pady=5)
    buttonSm.grid(row=0, column=8, padx=5, pady=5)
    buttonEu.grid(row=0, column=9, padx=5, pady=5)
    buttonGd.grid(row=0, column=10, padx=5, pady=5)
    buttonTb.grid(row=0, column=11, padx=5, pady=5)
    buttonDy.grid(row=0, column=12, padx=5, pady=5)
    buttonHo.grid(row=0, column=13, padx=5, pady=5)
    buttonEr.grid(row=0, column=14, padx=5, pady=5)
    buttonTm.grid(row=0, column=15, padx=5, pady=5)
    buttonYb.grid(row=0, column=16, padx=5, pady=5)
    buttonLu.grid(row=0, column=17, padx=5, pady=5)
    buttonTh = tk.Button(uklad2, text="Th", command=Tor)
    buttonPa = tk.Button(uklad2, text="Pa", command=Protaktyn)
    buttonU = tk.Button(uklad2, text="U", command=Uran)
    buttonNp = tk.Button(uklad2, text="Np", command=Neptun)
    buttonPu = tk.Button(uklad2, text="Pu", command=Pluton)
    buttonAm = tk.Button(uklad2, text="Am", command=Ameryk)
    buttonCm = tk.Button(uklad2, text="Cm", command=Kiur)
    buttonBk = tk.Button(uklad2, text="Bk", command=Berkel)
    buttonCf = tk.Button(uklad2, text="Cf", command=Kaliforn)
    buttonEs = tk.Button(uklad2, text="Es", command=Einstein)
    buttonFm = tk.Button(uklad2, text="Fm", command=Ferm)
    buttonMd = tk.Button(uklad2, text="Md", command=Mendelew)
    buttonNo = tk.Button(uklad2, text="No", command=Nobel)
    buttonLr = tk.Button(uklad2, text="Lr", command=Lorens)
    buttonTh.grid(row=1, column=4, padx=5, pady=5)
    buttonPa.grid(row=1, column=5, padx=5, pady=5)
    buttonU.grid(row=1, column=6, padx=5, pady=5)
    buttonNp.grid(row=1, column=7, padx=5, pady=5)
    buttonPu.grid(row=1, column=8, padx=5, pady=5)
    buttonAm.grid(row=1, column=9, padx=5, pady=5)
    buttonCm.grid(row=1, column=10, padx=5, pady=5)
    buttonBk.grid(row=1, column=11, padx=5, pady=5)
    buttonCf.grid(row=1, column=12, padx=5, pady=5)
    buttonEs.grid(row=1, column=13, padx=5, pady=5)
    buttonFm.grid(row=1, column=14, padx=5, pady=5)
    buttonMd.grid(row=1, column=15, padx=5, pady=5)
    buttonNo.grid(row=1, column=16, padx=5, pady=5)
    buttonLr.grid(row=1, column=17, padx=5, pady=5)


