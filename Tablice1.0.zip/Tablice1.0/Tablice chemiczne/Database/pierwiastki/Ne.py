import tkinter as tk

def Neon():
    print("[Otwarto tablicę: Neon]")

    # Tworzenie głównego okna
    tablica = tk.Tk()
    tablica.title("Neon")
    tablica.geometry("1200x700")

    # Nagłówek
    tytul = tk.Label(tablica, text="Ne", font=("Arial", 40))
    tytul.pack(pady=5)
    ptytul = tk.Label(tablica, text="Neon", font=("Arial", 15))
    ptytul.pack(pady=0)

    # Tworzenie ramki dla informacji
    info = tk.Frame(tablica, bd=5, relief="ridge")
    info.pack(padx=5, pady=20)

    # Ramka dla ogólnych właściwości
    og = tk.Frame(info, bd=5, relief="ridge")
    og.grid(row=0, column=0, padx=20)

    # Dodawanie etykiet do ramki ogólnych właściwości
    og0 = tk.Label(og, text="Charakterystyka", font=("Arial", 10, "bold"))
    og1 = tk.Label(og, text="Nazwa:", font=("Arial", 10, "bold"))
    og2 = tk.Label(og, text="Neon", font=("Arial", 10))
    og3 = tk.Label(og, text="Symbol:", font=("Arial", 10, "bold"))
    og4 = tk.Label(og, text="Ne", font=("Arial", 10))
    og5 = tk.Label(og, text="Elektroujemność wg Paulinga:", font=("Arial", 10, "bold"))
    og6 = tk.Label(og, text="—", font=("Arial", 10))  # Brak wartości
    og7 = tk.Label(og, text="Stopnie utlenienia:", font=("Arial", 10, "bold"))
    og8 = tk.Label(og, text="0", font=("Arial", 10))
    og9 = tk.Label(og, text="Masa atomowa:", font=("Arial", 10, "bold"))
    og10 = tk.Label(og, text="20,180", font=("Arial", 10))
    og11 = tk.Label(og, text="Liczba atomowa:", font=("Arial", 10, "bold"))
    og12 = tk.Label(og, text="10", font=("Arial", 10))
    og13 = tk.Label(og, text="Stan skupienia (w temp. pokojowej):", font=("Arial", 10, "bold"))
    og14 = tk.Label(og, text="Gaz", font=("Arial", 10))

    # Układanie etykiet w siatce
    og0.grid(row=0, column=0, padx=0)
    og1.grid(row=1, column=0, padx=0)
    og2.grid(row=1, column=1, padx=0)
    og3.grid(row=2, column=0, padx=0)
    og4.grid(row=2, column=1, padx=0)
    og5.grid(row=3, column=0, padx=0)
    og6.grid(row=3, column=1, padx=0)
    og7.grid(row=4, column=0, padx=0)
    og8.grid(row=4, column=1, padx=0)
    og9.grid(row=5, column=0, padx=0)
    og10.grid(row=5, column=1, padx=0)
    og11.grid(row=6, column=0, padx=0)
    og12.grid(row=6, column=1, padx=0)
    og13.grid(row=7, column=0, padx=0)
    og14.grid(row=7, column=1, padx=0)

    # Ramka dla danych strukturalnych
    dane = tk.Frame(info, bd=5, relief="ridge")
    dane.grid(row=0, column=1, padx=20)

    # Dodawanie etykiet do ramki danych strukturalnych
    budowa0 = tk.Label(dane, text="Budowa", font=("Arial", 10, "bold"))
    budowa1 = tk.Label(dane, text="Protony:", font=("Arial", 10, "bold"))
    budowa2 = tk.Label(dane, text="10", font=("Arial", 10))
    budowa3 = tk.Label(dane, text="Neutrony:", font=("Arial", 10, "bold"))
    budowa4 = tk.Label(dane, text="10", font=("Arial", 10))
    budowa5 = tk.Label(dane, text="Elektrony:", font=("Arial", 10, "bold"))
    budowa6 = tk.Label(dane, text="10", font=("Arial", 10))
    budowa7 = tk.Label(dane, text="Powłoki:", font=("Arial", 10, "bold"))
    budowa8 = tk.Label(dane, text="K 2, L 8", font=("Arial", 10))
    budowa9 = tk.Label(dane, text="Promień atomowy:", font=("Arial", 10, "bold"))
    budowa10 = tk.Label(dane, text="38 pm", font=("Arial", 10))

    budowa11 = tk.Label(dane, text="Promień kowalencyjny:", font=("Arial", 10, "bold"))
    budowa12 = tk.Label(dane, text="—", font=("Arial", 10))  # Brak wartości
    budowa13 = tk.Label(dane, text="Promień van der Waalsa:", font=("Arial", 10, "bold"))
    budowa14 = tk.Label(dane, text="—", font=("Arial", 10))  # Brak wartości

    # Układanie etykiet w siatce
    budowa0.grid(row=0, column=0, padx=0)
    budowa1.grid(row=1, column=0, padx=0)
    budowa2.grid(row=1, column=1, padx=0)
    budowa3.grid(row=2, column=0, padx=0)
    budowa4.grid(row=2, column=1, padx=0)
    budowa5.grid(row=3, column=0, padx=0)
    budowa6.grid(row=3, column=1, padx=0)
    budowa7.grid(row=4, column=0, padx=0)
    budowa8.grid(row=4, column=1, padx=0)
    budowa9.grid(row=5, column=0, padx=0)
    budowa10.grid(row=5, column=1, padx=0)

    budowa11.grid(row=6, column=0, padx=0)
    budowa12.grid(row=6, column=1, padx=0)
    budowa13.grid(row=7, column=0, padx=0)
    budowa14.grid(row=7, column=1, padx=0)

    # Ramka dla właściwości termodynamicznych
    thermo = tk.Frame(info, bd=5, relief="ridge")
    thermo.grid(row=0, column=2, padx=20)

    thermo0 = tk.Label(thermo, text="Właściwości termodynamiczne", font=("Arial", 10, "bold"))
    thermo1 = tk.Label(thermo, text="Temperatura topnienia:", font=("Arial", 10, "bold"))
    thermo2 = tk.Label(thermo, text="24,56 K", font=("Arial", 10))
    thermo3 = tk.Label(thermo, text="Temperatura wrzenia:", font=("Arial", 10, "bold"))
    thermo4 = tk.Label(thermo, text="27,07 K", font=("Arial", 10))
    thermo5 = tk.Label(thermo, text="Ciepło topnienia:", font=("Arial", 10, "bold"))
    thermo6 = tk.Label(thermo, text="1,70 kJ/mol", font=("Arial", 10))
    thermo7 = tk.Label(thermo, text="Ciepło parowania:", font=("Arial", 10, "bold"))
    thermo8 = tk.Label(thermo, text="1,70 kJ/mol", font=("Arial", 10))
    thermo9 = tk.Label(thermo, text="Pojemność cieplna molowa:", font=("Arial", 10, "bold"))
    thermo10 = tk.Label(thermo, text="20,78 J/(mol·K)", font=("Arial", 10))

    # Układanie etykiet w siatce
    thermo0.grid(row=0, column=0, padx=0)
    thermo1.grid(row=1, column=0, padx=0)
    thermo2.grid(row=1, column=1, padx=0)
    thermo3.grid(row=2, column=0, padx=0)
    thermo4.grid(row=2, column=1, padx=0)
    thermo5.grid(row=3, column=0, padx=0)
    thermo6.grid(row=3, column=1, padx=0)
    thermo7.grid(row=4, column=0, padx=0)
    thermo8.grid(row=4, column=1, padx=0)
    thermo9.grid(row=5, column=0, padx=0)
    thermo10.grid(row=5, column=1, padx=0)

    # Ramka dla właściwości chemicznych
    chem = tk.Frame(info, bd=5, relief="ridge")
    chem.grid(row=1, column=0, columnspan=3, pady=20)

    chem0 = tk.Label(chem, text="Właściwości chemiczne", font=("Arial", 10, "bold"))
    chem1 = tk.Label(chem, text="Stan skupienia:", font=("Arial", 10, "bold"))
    chem2 = tk.Label(chem, text="Gaz w warunkach normalnych", font=("Arial", 10))
    chem3 = tk.Label(chem, text="Kolor:", font=("Arial", 10, "bold"))
    chem4 = tk.Label(chem, text="Bezbarwny", font=("Arial", 10))
    chem5 = tk.Label(chem, text="Zapach:", font=("Arial", 10, "bold"))
    chem6 = tk.Label(chem, text="Brak", font=("Arial", 10))
    chem7 = tk.Label(chem, text="Reaktywność:", font=("Arial", 10, "bold"))
    chem8 = tk.Label(chem, text="Niska reaktywność", font=("Arial", 10))
    chem9 = tk.Label(chem, text="Liczba izotopów:", font=("Arial", 10, "bold"))
    chem10 = tk.Label(chem, text="3 (20Ne, 21Ne, 22Ne)", font=("Arial", 10))
    chem11 = tk.Label(chem, text="Izotop stabilny:", font=("Arial", 10, "bold"))
    chem12 = tk.Label(chem, text="20Ne, 21Ne, 22Ne", font=("Arial", 10))

    # Układanie etykiet w siatce
    chem0.grid(row=0, column=0, padx=0)
    chem1.grid(row=1, column=0, padx=0)
    chem2.grid(row=1, column=1, padx=0)
    chem3.grid(row=2, column=0, padx=0)
    chem4.grid(row=2, column=1, padx=0)
    chem5.grid(row=3, column=0, padx=0)
    chem6.grid(row=3, column=1, padx=0)
    chem7.grid(row=4, column=0, padx=0)
    chem8.grid(row=4, column=1, padx=0)
    chem9.grid(row=5, column=0, padx=0)
    chem10.grid(row=5, column=1, padx=0)
    chem11.grid(row=6, column=0, padx=0)
    chem12.grid(row=6, column=1, padx=0)
