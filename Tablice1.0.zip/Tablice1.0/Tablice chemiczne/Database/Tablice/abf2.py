import tkinter as tk

x = 0

def abf_change():
    global x  
    try:
        if x == 0:
            x += 1  
        else:
            x = 0
        update_image()
    except NameError:
        x = 0  

def update_image():
    """ Function to update the image displayed in the tkinter window based on the value of x """
    if x == 0:
        img19 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\wybrane aminokwasy białkowe.png')
    else:
        img19 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\wybrane aminokwasy białkowe2.png')
    image_label.configure(image=img19)
    image_label.image = img19  

def abf():
    global x
    global image_label 
    ab = tk.Toplevel()
    ab.title("aminokwasy białkowe")
    ab.geometry('1142x735')
    ab.iconbitmap(r"C:\Program Files\Tablice chemiczne\icon.ico")
    print("[Otwarto aminokwasy białkowe]")
    
    try:
        img19 = tk.PhotoImage(file=r'C:\Program Files\Tablice chemiczne\Database\tablice\wybrane aminokwasy białkowe.png')
        image_label = tk.Label(ab, image=img19)
        image_label.pack()
        image_label.image = img19 
        
        ab_ch = tk.Button(ab, text="Zmiana strony", command=abf_change)
        ab_ch.pack(padx=0)

        
    except Exception as e:
        print(f"Error: {e}")
        x = 0

    ab.mainloop()


